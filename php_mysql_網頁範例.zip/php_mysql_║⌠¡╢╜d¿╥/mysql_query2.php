﻿<?
$conn = mysql_connect("localhost", "mtchang", "qw") or die("Could not connect");
mysql_query("SET NAMES 'utf8'");
mysql_select_db("mtchang", $conn);
$sql = "select * from students";
$result = mysql_query($sql);
$nbfields = mysql_num_fields($result);

echo "<TABLE BORDER=1>\n";
echo "<TR>\n" ;
while ($field = mysql_fetch_field($result))
{
       echo "<TD>" . $field->name . "</TD>";
}
echo "</TR>\n";

while ($row = mysql_fetch_row($result))
{
       echo "<TR>\n";
       for($i = 0 ; $i < $nbfields ; $i++)
       {
             echo "<TD>" . $row[$i] . "</TD>";
       }
       echo "</TR>\n";
}
echo "</TABLE>";
?>