﻿<a href="http://127.0.0.1/myweb/sql/mtchang/mysql_query4.php?page=1">page1</a> 
<a href="http://127.0.0.1/myweb/sql/mtchang/mysql_query4.php?page=2">page2</a> 

<?
$conn = mysql_connect("localhost", "mtchang", "qw") or die("Could not connect");
mysql_query("SET NAMES 'utf8'");
mysql_select_db("mtchang", $conn);
$page_max=10;
$page_start=$page_max*$_GET['page'];
$sql = "select * from students limit $page_start,$page_max";
$result = mysql_query($sql);
$nbfields = mysql_num_fields($result);

echo "<TABLE BORDER=1>\n";
echo "<TR>\n" ;
while ($field = mysql_fetch_field($result))
{
       echo "<TD>" . $field->name . "</TD>";
}
echo "</TR>\n";

while ($row = mysql_fetch_row($result))
{
       echo "<TR>\n";
       for($i = 0 ; $i < $nbfields ; $i++)
       {
             echo "<TD>" . $row[$i] . "</TD>";
       }
       echo "</TR>\n";
}
echo "</TABLE>";
?>