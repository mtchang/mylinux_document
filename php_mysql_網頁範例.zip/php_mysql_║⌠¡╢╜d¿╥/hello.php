﻿<?
echo "hello 中文!!";
?>