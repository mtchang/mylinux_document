﻿<form enctype="multipart/form-data" action="mysql_inject.php" method="post" name="mysql-test" target="_self">
<input name="query" type="text" value="" size="60" maxlength="300" />
<input type="submit" name="Submit" value="送出" />
</form>

<?
# 設定mysql的連線ID
$conn = mysql_connect("localhost", "mtchang", "qw") or die("Could not connect");
# 設定再查詢mysql使用的字元編碼為UTF-8。很重要，沒設定出來會都是亂碼
mysql_query("SET NAMES 'utf8'");
# 選取資料庫
mysql_select_db("mtchang", $conn);
# 設定SQL敘述
$sql='SELECT * FROM students WHERE 學號='.$_POST['query'].';';
# 顯示目前執行的SQL敘述
echo '目前執行的SQL的敘述為'.$sql.'<br />';
# 將SQL敘述傳給SQL server查詢，並節回傳結果放在變數$result
$result = mysql_query($sql);
if($result)
    echo "認證通過<br />";
else
    echo "認證失敗<br />";

# 計算此SQL表格有多少欄位
$nbfields = mysql_num_fields($result);

# 迴圈，讀取$result裡面的內容，直到空為止
while ($row = mysql_fetch_row($result))
{
       # 迴圈，讀取列。依據欄位數顯示row植
       for($i = 0 ; $i < $nbfields ; $i++)
       {
             echo $row[$i] . "  ";
       }
	   # html的斷行
       echo "<br />";
}
?>